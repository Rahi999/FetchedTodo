import "./styles.css";
import Todo from "./components/Todo"


export default function App() {
  return (
    <div className="App">
    
    
       <Todo /> 
    </div>
  );
}
